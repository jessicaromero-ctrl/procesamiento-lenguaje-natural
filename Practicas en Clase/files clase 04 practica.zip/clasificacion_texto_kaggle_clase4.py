"""
UPMH - Procesamiento de Lenguaje Natural - Clase 4
Autor: M.C. Pablo Ricardo Sanchez Gomez

Practica: dataset ampliado, comparacion de modelos y analisis de errores.
Ambiente: Python 3.11, Miniconda y Visual Studio Code.

Objetivo:
Comparar cuatro modelos supervisados (NB, CNB, LR, SVM) para clasificar
textos usando TF-IDF, evaluar con metricas macro y analizar errores.

Uso:
    python clasificacion_texto_kaggle_clase4.py \
        --csv datos/comentarios_ampliados_clase4.csv \
        --text-col texto \
        --label-col categoria \
        --output-dir salidas_clase4

    # Para dataset tipo Kaggle:
    python clasificacion_texto_kaggle_clase4.py \
        --csv datos/archivo_kaggle.csv \
        --text-col News \
        --label-col Type \
        --output-dir salidas_kaggle \
        --max-rows 5000
"""

import argparse
import re
import unicodedata
from pathlib import Path

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.naive_bayes import MultinomialNB, ComplementNB
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    classification_report,
    confusion_matrix,
)

STOPWORDS_ES = [
    "el", "la", "los", "las", "un", "una", "unos", "unas",
    "de", "del", "y", "o", "pero", "aunque", "a", "en", "con",
    "por", "para", "que", "se", "al", "lo", "es", "fue", "muy",
    "mas", "menos", "durante", "desde", "sobre", "sin", "su", "sus",
    "me", "mi", "mis", "si", "no", "hay", "este", "esta", "ese",
]


# ---------------------------------------------------------------------------
# Preprocesamiento
# ---------------------------------------------------------------------------

def quitar_acentos(texto: str) -> str:
    normalizado = unicodedata.normalize("NFD", texto)
    return "".join(c for c in normalizado if unicodedata.category(c) != "Mn")


def limpiar_texto(texto: str) -> str:
    texto = str(texto).lower()
    texto = quitar_acentos(texto)
    texto = re.sub(r"[^a-zn0-9\s]", " ", texto)
    texto = re.sub(r"\s+", " ", texto).strip()
    return texto


# ---------------------------------------------------------------------------
# Carga y validacion
# ---------------------------------------------------------------------------

def cargar_datos(ruta: Path, col_texto: str, col_etiqueta: str, max_rows: int | None) -> pd.DataFrame:
    if not ruta.exists():
        raise FileNotFoundError(f"No existe el archivo: {ruta}")

    df = pd.read_csv(ruta, encoding="utf-8-sig", nrows=max_rows)

    for col in [col_texto, col_etiqueta]:
        if col not in df.columns:
            raise ValueError(
                f"Columna '{col}' no encontrada. Columnas disponibles: {list(df.columns)}"
            )

    df = df[[col_texto, col_etiqueta]].dropna()
    df.columns = ["texto", "categoria"]
    df["texto_limpio"] = df["texto"].apply(limpiar_texto)
    return df


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------

def crear_pipeline(modelo) -> Pipeline:
    vectorizador = TfidfVectorizer(
        preprocessor=limpiar_texto,
        lowercase=False,
        stop_words=STOPWORDS_ES,
        ngram_range=(1, 2),
        min_df=2,
        max_df=0.90,
        max_features=5000,
        sublinear_tf=True,
    )
    return Pipeline([("tfidf", vectorizador), ("modelo", modelo)])


# ---------------------------------------------------------------------------
# Evaluacion
# ---------------------------------------------------------------------------

def evaluar_modelo(nombre, pipeline, x_train, x_test, y_train, y_test):
    pipeline.fit(x_train, y_train)
    pred = pipeline.predict(x_test)

    precision, recall, f1, _ = precision_recall_fscore_support(
        y_test, pred, average="macro", zero_division=0
    )
    acc = accuracy_score(y_test, pred)

    metricas = {
        "modelo": nombre,
        "accuracy": round(acc, 4),
        "precision_macro": round(precision, 4),
        "recall_macro": round(recall, 4),
        "f1_macro": round(f1, 4),
    }

    reporte = classification_report(y_test, pred, zero_division=0, output_dict=True)
    etiquetas = sorted(y_test.unique())
    matriz = confusion_matrix(y_test, pred, labels=etiquetas)

    errores = pd.DataFrame({
        "texto": x_test.values,
        "categoria_real": y_test.values,
        "categoria_predicha": pred,
        "modelo": nombre,
        "correcto": y_test.values == pred,
    })
    errores = errores[~errores["correcto"]].drop(columns="correcto")

    return metricas, reporte, matriz, errores, etiquetas


# ---------------------------------------------------------------------------
# Exportacion de matrices de confusion
# ---------------------------------------------------------------------------

def exportar_matriz_png(matriz: np.ndarray, etiquetas: list, nombre_modelo: str, ruta: Path) -> None:
    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(matriz, interpolation="nearest", cmap="Blues")
    plt.colorbar(im, ax=ax)

    ax.set_xticks(range(len(etiquetas)))
    ax.set_yticks(range(len(etiquetas)))
    ax.set_xticklabels(etiquetas, rotation=30, ha="right", fontsize=11)
    ax.set_yticklabels(etiquetas, fontsize=11)

    for i in range(len(etiquetas)):
        for j in range(len(etiquetas)):
            valor = matriz[i, j]
            color = "white" if valor > matriz.max() / 2 else "black"
            ax.text(j, i, str(valor), ha="center", va="center", color=color, fontsize=13, fontweight="bold")

    ax.set_ylabel("Clase real", fontsize=12)
    ax.set_xlabel("Clase predicha", fontsize=12)
    ax.set_title(f"Matriz de confusión\n{nombre_modelo}", fontsize=13, fontweight="bold")

    plt.tight_layout()
    plt.savefig(ruta, dpi=150)
    plt.close()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Clasificacion supervisada de texto - Clase 4 PLN")
    parser.add_argument("--csv", type=Path, required=True, help="Ruta al CSV de entrada")
    parser.add_argument("--text-col", default="texto", help="Nombre de la columna de texto")
    parser.add_argument("--label-col", default="categoria", help="Nombre de la columna de etiqueta")
    parser.add_argument("--output-dir", type=Path, default=Path("salidas_clase4"), help="Carpeta de salida")
    parser.add_argument("--max-rows", type=int, default=None, help="Limitar filas del CSV")
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)

    # 1. Cargar y preprocesar
    df = cargar_datos(args.csv, args.text_col, args.label_col, args.max_rows)
    df.to_csv(args.output_dir / "01_datos_preprocesados.csv", index=False, encoding="utf-8-sig")

    # 2. Dividir
    x_train, x_test, y_train, y_test = train_test_split(
        df["texto"], df["categoria"],
        test_size=0.25, random_state=42, stratify=df["categoria"]
    )

    # 3. Modelos
    modelos = {
        "naive_bayes_multinomial": crear_pipeline(MultinomialNB(alpha=1.0)),
        "complement_naive_bayes": crear_pipeline(ComplementNB(alpha=1.0)),
        "regresion_logistica": crear_pipeline(
            LogisticRegression(max_iter=1000, random_state=42, class_weight="balanced")
        ),
        "linear_svm": crear_pipeline(
            LinearSVC(max_iter=2000, random_state=42, class_weight="balanced")
        ),
    }

    resumen = []
    todos_errores = []
    mejor_nombre = None
    mejor_f1 = -1

    for nombre, pipeline in modelos.items():
        print(f"  Entrenando: {nombre}...", end=" ", flush=True)
        metricas, reporte, matriz, errores, etiquetas = evaluar_modelo(
            nombre, pipeline, x_train, x_test, y_train, y_test
        )
        resumen.append(metricas)
        todos_errores.append(errores)

        # Guardar matriz CSV individual
        df_matriz = pd.DataFrame(matriz, index=etiquetas, columns=etiquetas)
        df_matriz.to_csv(args.output_dir / f"matriz_confusion_{nombre}.csv", encoding="utf-8-sig")

        # Guardar matriz PNG
        exportar_matriz_png(
            matriz, etiquetas, nombre,
            args.output_dir / f"matriz_confusion_{nombre}.png"
        )

        if metricas["f1_macro"] > mejor_f1:
            mejor_f1 = metricas["f1_macro"]
            mejor_nombre = nombre

        print(f"F1={metricas['f1_macro']:.4f}")

    # 4. Comparativo
    df_resumen = pd.DataFrame(resumen).sort_values("f1_macro", ascending=False)
    df_resumen.to_csv(args.output_dir / "03_comparativo_modelos.csv", index=False, encoding="utf-8-sig")

    # 5. Errores consolidados
    df_errores = pd.concat(todos_errores, ignore_index=True)
    df_errores.to_csv(args.output_dir / "04_errores_modelos.csv", index=False, encoding="utf-8-sig")

    # 6. Predicciones del mejor modelo sobre todo el test
    mejor_pipeline = modelos[mejor_nombre]
    pred_mejor = mejor_pipeline.predict(x_test)
    df_pred = pd.DataFrame({
        "texto": x_test.values,
        "categoria_real": y_test.values,
        "categoria_predicha": pred_mejor,
        "correcto": y_test.values == pred_mejor,
    })
    df_pred.to_csv(args.output_dir / "05_predicciones_mejor_modelo.csv", index=False, encoding="utf-8-sig")

    # Resumen final
    print("\n" + "="*60)
    print("Clase 4 - PLN: dataset ampliado y comparacion de modelos")
    print(f"Registros totales : {len(df)}")
    print(f"Train / Test      : {len(x_train)} / {len(x_test)}")
    print(f"Clases            : {sorted(df['categoria'].unique())}")
    print(f"Mejor modelo      : {mejor_nombre}  (F1={mejor_f1:.4f})")
    print()
    print("Comparativo de modelos:")
    print(df_resumen.to_string(index=False))
    print()
    print(f"Archivos generados en: {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
