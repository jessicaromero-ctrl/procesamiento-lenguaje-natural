"""
UPMH - Procesamiento de Lenguaje Natural - Clase 3
Autor: M.C. Pablo Ricardo Sanchez Gomez

Practica: herramientas de PLN y primer modelo de clasificacion de textos.
Ambiente: Python 3.11, Miniconda y Visual Studio Code.

Objetivo:
Entrenar modelos supervisados para clasificar comentarios en tres categorias:
docente, contenido y plataforma.
"""

from pathlib import Path
import re
import unicodedata
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
from sklearn.metrics import classification_report, confusion_matrix

ARCHIVO_ENTRENAMIENTO = Path("comentarios_entrenamiento_clase3.csv")
ARCHIVO_NUEVOS = Path("comentarios_nuevos_clase3.csv")
CARPETA_SALIDAS = Path("salidas_clase3")

COLUMNAS_REQUERIDAS_ENTRENAMIENTO = {"id", "texto", "categoria"}
COLUMNAS_REQUERIDAS_NUEVOS = {"id", "texto"}

STOPWORDS_ES = [
    "el", "la", "los", "las", "un", "una", "unos", "unas",
    "de", "del", "y", "o", "pero", "aunque", "a", "en", "con",
    "por", "para", "que", "se", "al", "lo", "es", "fue", "muy",
    "mas", "menos", "durante", "desde", "sobre", "sin", "su", "sus",
]


def quitar_acentos(texto: str) -> str:
    """Elimina marcas diacriticas para tratar útil y util como la misma forma."""
    normalizado = unicodedata.normalize("NFD", texto)
    return "".join(caracter for caracter in normalizado if unicodedata.category(caracter) != "Mn")


def limpiar_texto(texto: str) -> str:
    """Normaliza texto antes de vectorizarlo."""
    texto = str(texto).lower()
    texto = quitar_acentos(texto)
    texto = re.sub(r"[^a-zñ0-9\s]", " ", texto)
    texto = re.sub(r"\s+", " ", texto).strip()
    return texto


def cargar_csv(ruta: Path, columnas_requeridas: set[str]) -> pd.DataFrame:
    """Carga un CSV y valida que tenga las columnas esperadas."""
    if not ruta.exists():
        raise FileNotFoundError(f"No existe el archivo requerido: {ruta}")

    datos = pd.read_csv(ruta, encoding="utf-8-sig")
    columnas_actuales = set(datos.columns)
    faltantes = columnas_requeridas - columnas_actuales

    if faltantes:
        raise ValueError(f"Al archivo {ruta} le faltan columnas: {sorted(faltantes)}")

    return datos


def crear_pipeline(modelo):
    """Construye un Pipeline de scikit-learn: vectorizador TF-IDF + clasificador."""
    vectorizador = TfidfVectorizer(
        preprocessor=limpiar_texto,
        lowercase=False,
        stop_words=STOPWORDS_ES,
        ngram_range=(1, 2),
        min_df=1,
        max_features=120,
        sublinear_tf=True,
    )
    return Pipeline([
        ("tfidf", vectorizador),
        ("modelo", modelo),
    ])


def evaluar_modelo(nombre: str, modelo, x_train, x_test, y_train, y_test):
    """Entrena un modelo, calcula predicciones y devuelve metricas principales."""
    modelo.fit(x_train, y_train)
    predicciones = modelo.predict(x_test)

    precision, recall, f1, _ = precision_recall_fscore_support(
        y_test,
        predicciones,
        average="macro",
        zero_division=0,
    )

    metricas = {
        "modelo": nombre,
        "accuracy": accuracy_score(y_test, predicciones),
        "precision_macro": precision,
        "recall_macro": recall,
        "f1_macro": f1,
    }

    reporte = classification_report(y_test, predicciones, zero_division=0, output_dict=True)
    matriz = confusion_matrix(y_test, predicciones, labels=sorted(y_test.unique()))

    return metricas, reporte, matriz, predicciones


def exportar_vocabulario_y_matriz(modelo_entrenado, textos: pd.Series, ids: pd.Series):
    """Exporta vocabulario y matriz TF-IDF generada por el pipeline seleccionado."""
    vectorizador = modelo_entrenado.named_steps["tfidf"]
    matriz = vectorizador.transform(textos)
    vocabulario = vectorizador.get_feature_names_out()

    df_vocabulario = pd.DataFrame({"termino": vocabulario})
    df_matriz = pd.DataFrame(matriz.toarray(), columns=vocabulario)
    df_matriz.insert(0, "id", ids.values)

    df_vocabulario.to_csv(CARPETA_SALIDAS / "03_vocabulario_tfidf.csv", index=False, encoding="utf-8-sig")
    df_matriz.to_csv(CARPETA_SALIDAS / "04_matriz_tfidf.csv", index=False, encoding="utf-8-sig")


def main() -> None:
    CARPETA_SALIDAS.mkdir(exist_ok=True)

    datos = cargar_csv(ARCHIVO_ENTRENAMIENTO, COLUMNAS_REQUERIDAS_ENTRENAMIENTO)
    nuevos = cargar_csv(ARCHIVO_NUEVOS, COLUMNAS_REQUERIDAS_NUEVOS)

    datos["texto_limpio"] = datos["texto"].apply(limpiar_texto)
    datos.to_csv(CARPETA_SALIDAS / "01_datos_preprocesados.csv", index=False, encoding="utf-8-sig")

    x_train, x_test, y_train, y_test = train_test_split(
        datos["texto"],
        datos["categoria"],
        test_size=0.30,
        random_state=42,
        stratify=datos["categoria"],
    )

    modelos = {
        "naive_bayes_multinomial": crear_pipeline(MultinomialNB(alpha=1.0)),
        "regresion_logistica": crear_pipeline(LogisticRegression(max_iter=1000, random_state=42)),
    }

    resumen_metricas = []
    reportes = {}
    matrices = {}
    predicciones_prueba = {}

    for nombre, modelo in modelos.items():
        metricas, reporte, matriz, predicciones = evaluar_modelo(nombre, modelo, x_train, x_test, y_train, y_test)
        resumen_metricas.append(metricas)
        reportes[nombre] = reporte
        matrices[nombre] = matriz
        predicciones_prueba[nombre] = predicciones

    df_metricas = pd.DataFrame(resumen_metricas).sort_values("f1_macro", ascending=False)
    df_metricas.to_csv(CARPETA_SALIDAS / "02_metricas_modelos.csv", index=False, encoding="utf-8-sig")

    mejor_modelo_nombre = df_metricas.iloc[0]["modelo"]
    mejor_modelo = modelos[mejor_modelo_nombre]

    etiquetas_ordenadas = sorted(y_test.unique())
    df_matriz = pd.DataFrame(matrices[mejor_modelo_nombre], index=etiquetas_ordenadas, columns=etiquetas_ordenadas)
    df_matriz.to_csv(CARPETA_SALIDAS / "05_matriz_confusion_mejor_modelo.csv", encoding="utf-8-sig")

    df_predicciones = pd.DataFrame({
        "texto": x_test.values,
        "categoria_real": y_test.values,
        "categoria_predicha": predicciones_prueba[mejor_modelo_nombre],
        "modelo": mejor_modelo_nombre,
    })
    df_predicciones.to_csv(CARPETA_SALIDAS / "06_predicciones_prueba.csv", index=False, encoding="utf-8-sig")

    exportar_vocabulario_y_matriz(mejor_modelo, datos["texto"], datos["id"])

    nuevos["categoria_predicha"] = mejor_modelo.predict(nuevos["texto"])
    nuevos.to_csv(CARPETA_SALIDAS / "07_predicciones_nuevos_comentarios.csv", index=False, encoding="utf-8-sig")

    print("Clase 3 - PLN: clasificacion supervisada de textos")
    print("Modelo seleccionado:", mejor_modelo_nombre)
    print("\nMetricas principales:")
    print(df_metricas.to_string(index=False))
    print("\nArchivos generados en:", CARPETA_SALIDAS.resolve())


if __name__ == "__main__":
    main()
