from pathlib import Path
import csv
import math
import re
import unicodedata
from collections import Counter

ARCHIVO_ENTRADA = Path("comentarios_clase2.csv")
CARPETA_SALIDA = Path("salidas_clase2")

STOPWORDS = {
    "el", "la", "los", "las", "un", "una", "unos", "unas",
    "de", "del", "y", "o", "pero", "aunque", "a", "en", "con",
    "por", "para", "me", "mi", "mis", "es", "fue", "muy", "que",
    "se", "al", "lo", "no", "su", "sus", "eso", "si", "sin",
    "porque", "como", "cuando", "cuales", "cuál", "cual"
}


def quitar_acentos(texto: str) -> str:
    texto_normalizado = unicodedata.normalize("NFD", texto)
    caracteres = [
        caracter
        for caracter in texto_normalizado
        if unicodedata.category(caracter) != "Mn"
    ]
    return "".join(caracteres)


def limpiar_texto(texto: str) -> str:
    texto = texto.lower()
    texto = quitar_acentos(texto)
    texto = re.sub(r"[^a-zñ0-9\s]", " ", texto)
    texto = re.sub(r"\s+", " ", texto).strip()
    return texto


def tokenizar(texto_limpio: str) -> list[str]:
    return texto_limpio.split()


def quitar_stopwords(tokens: list[str]) -> list[str]:
    return [
        token
        for token in tokens
        if token not in STOPWORDS and len(token) > 2
    ]


def cargar_comentarios(ruta: Path) -> list[dict[str, str]]:
    if not ruta.exists():
        raise FileNotFoundError(f"No existe el archivo de entrada: {ruta.resolve()}")

    with ruta.open("r", encoding="utf-8-sig", newline="") as archivo:
        lector = csv.DictReader(archivo)
        return [fila for fila in lector]


def preprocesar_comentarios(comentarios: list[dict[str, str]]) -> list[dict[str, object]]:
    documentos = []

    for fila in comentarios:
        texto_original = fila["texto"]
        texto_limpio = limpiar_texto(texto_original)
        tokens = tokenizar(texto_limpio)
        tokens_utiles = quitar_stopwords(tokens)

        documentos.append({
            "id": fila["id"],
            "texto_original": texto_original,
            "texto_limpio": texto_limpio,
            "tokens_utiles": tokens_utiles,
            "origen": fila.get("origen", "")
        })

    return documentos


def construir_vocabulario(documentos: list[dict[str, object]]) -> list[str]:
    vocabulario = set()

    for documento in documentos:
        vocabulario.update(documento["tokens_utiles"])

    return sorted(vocabulario)


def construir_matriz_bow(documentos: list[dict[str, object]], vocabulario: list[str]) -> list[dict[str, object]]:
    matriz = []

    for documento in documentos:
        conteo = Counter(documento["tokens_utiles"])
        fila = {"id": documento["id"]}

        for termino in vocabulario:
            fila[termino] = conteo.get(termino, 0)

        matriz.append(fila)

    return matriz


def calcular_matriz_tf(matriz_bow: list[dict[str, object]], vocabulario: list[str]) -> list[dict[str, object]]:
    matriz_tf = []

    for fila_bow in matriz_bow:
        total_palabras = sum(int(fila_bow[termino]) for termino in vocabulario)
        fila_tf = {"id": fila_bow["id"]}

        for termino in vocabulario:
            if total_palabras == 0:
                fila_tf[termino] = 0.0
            else:
                fila_tf[termino] = int(fila_bow[termino]) / total_palabras

        matriz_tf.append(fila_tf)

    return matriz_tf


def calcular_idf(matriz_bow: list[dict[str, object]], vocabulario: list[str]) -> dict[str, float]:
    total_documentos = len(matriz_bow)
    valores_idf = {}

    for termino in vocabulario:
        documentos_con_termino = sum(
            1
            for fila_bow in matriz_bow
            if int(fila_bow[termino]) > 0
        )
        valores_idf[termino] = math.log((total_documentos + 1) / (documentos_con_termino + 1)) + 1

    return valores_idf


def construir_matriz_tfidf(
    matriz_tf: list[dict[str, object]],
    valores_idf: dict[str, float],
    vocabulario: list[str]
) -> list[dict[str, object]]:
    matriz_tfidf = []

    for fila_tf in matriz_tf:
        fila_tfidf = {"id": fila_tf["id"]}

        for termino in vocabulario:
            fila_tfidf[termino] = float(fila_tf[termino]) * valores_idf[termino]

        matriz_tfidf.append(fila_tfidf)

    return matriz_tfidf


def similitud_coseno(vector_a: list[float], vector_b: list[float]) -> float:
    producto_punto = sum(a * b for a, b in zip(vector_a, vector_b))
    magnitud_a = math.sqrt(sum(a * a for a in vector_a))
    magnitud_b = math.sqrt(sum(b * b for b in vector_b))

    if magnitud_a == 0 or magnitud_b == 0:
        return 0.0

    return producto_punto / (magnitud_a * magnitud_b)


def calcular_similitudes(matriz_tfidf: list[dict[str, object]], vocabulario: list[str]) -> list[dict[str, object]]:
    similitudes = []

    for i in range(len(matriz_tfidf)):
        for j in range(i + 1, len(matriz_tfidf)):
            documento_a = matriz_tfidf[i]
            documento_b = matriz_tfidf[j]
            vector_a = [float(documento_a[termino]) for termino in vocabulario]
            vector_b = [float(documento_b[termino]) for termino in vocabulario]
            similitud = similitud_coseno(vector_a, vector_b)

            similitudes.append({
                "documento_a": documento_a["id"],
                "documento_b": documento_b["id"],
                "similitud_coseno": round(similitud, 4)
            })

    return sorted(similitudes, key=lambda fila: fila["similitud_coseno"], reverse=True)


def obtener_top_terminos(
    documentos: list[dict[str, object]],
    matriz_tfidf: list[dict[str, object]],
    vocabulario: list[str],
    cantidad: int = 5
) -> list[dict[str, object]]:
    filas = []

    for documento, fila_tfidf in zip(documentos, matriz_tfidf):
        terminos_ordenados = sorted(
            vocabulario,
            key=lambda termino: float(fila_tfidf[termino]),
            reverse=True
        )[:cantidad]

        filas.append({
            "id": documento["id"],
            "texto_original": documento["texto_original"],
            "top_terminos_tfidf": ", ".join(terminos_ordenados)
        })

    return filas


def guardar_csv(ruta: Path, filas: list[dict[str, object]], campos: list[str]) -> None:
    with ruta.open("w", encoding="utf-8-sig", newline="") as archivo:
        escritor = csv.DictWriter(archivo, fieldnames=campos)
        escritor.writeheader()
        escritor.writerows(filas)


def guardar_matriz(ruta: Path, matriz: list[dict[str, object]], vocabulario: list[str]) -> None:
    campos = ["id"] + vocabulario
    guardar_csv(ruta, matriz, campos)


def main() -> None:
    CARPETA_SALIDA.mkdir(exist_ok=True)

    comentarios = cargar_comentarios(ARCHIVO_ENTRADA)
    documentos = preprocesar_comentarios(comentarios)
    vocabulario = construir_vocabulario(documentos)
    matriz_bow = construir_matriz_bow(documentos, vocabulario)
    matriz_tf = calcular_matriz_tf(matriz_bow, vocabulario)
    valores_idf = calcular_idf(matriz_bow, vocabulario)
    matriz_tfidf = construir_matriz_tfidf(matriz_tf, valores_idf, vocabulario)
    similitudes = calcular_similitudes(matriz_tfidf, vocabulario)
    top_terminos = obtener_top_terminos(documentos, matriz_tfidf, vocabulario)

    guardar_csv(
        CARPETA_SALIDA / "01_preprocesamiento.csv",
        [
            {
                "id": documento["id"],
                "texto_original": documento["texto_original"],
                "texto_limpio": documento["texto_limpio"],
                "tokens_utiles": ", ".join(documento["tokens_utiles"])
            }
            for documento in documentos
        ],
        ["id", "texto_original", "texto_limpio", "tokens_utiles"]
    )
    guardar_matriz(CARPETA_SALIDA / "02_matriz_bow.csv", matriz_bow, vocabulario)
    guardar_matriz(CARPETA_SALIDA / "03_matriz_tf.csv", matriz_tf, vocabulario)
    guardar_matriz(CARPETA_SALIDA / "04_matriz_tfidf.csv", matriz_tfidf, vocabulario)
    guardar_csv(
        CARPETA_SALIDA / "05_top_terminos_tfidf.csv",
        top_terminos,
        ["id", "texto_original", "top_terminos_tfidf"]
    )
    guardar_csv(
        CARPETA_SALIDA / "06_similitud_documentos.csv",
        similitudes[:20],
        ["documento_a", "documento_b", "similitud_coseno"]
    )

    print("Documentos procesados:", len(documentos))
    print("Tamaño del vocabulario:", len(vocabulario))
    print("Archivos generados en:", CARPETA_SALIDA.resolve())
    print("Top 5 similitudes:")
    for fila in similitudes[:5]:
        print(fila)


if __name__ == "__main__":
    main()
