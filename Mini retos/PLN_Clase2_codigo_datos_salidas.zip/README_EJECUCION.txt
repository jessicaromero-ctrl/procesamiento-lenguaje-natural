Clase 2 - Procesamiento de Lenguaje Natural
Unidad 1: Preprocesamiento y representación de texto

Ambiente obligatorio:
- Python 3.11
- Miniconda
- Visual Studio Code

Ejecución:
1. Abrir esta carpeta en Visual Studio Code.
2. Activar el ambiente:
   conda activate pln311
3. Ejecutar:
   python pipeline_representacion_clase2.py

Archivos de entrada:
- comentarios_clase2.csv

Archivos generados:
- salidas_clase2/01_preprocesamiento.csv
- salidas_clase2/02_matriz_bow.csv
- salidas_clase2/03_matriz_tf.csv
- salidas_clase2/04_matriz_tfidf.csv
- salidas_clase2/05_top_terminos_tfidf.csv
- salidas_clase2/06_similitud_documentos.csv

Objetivo:
Convertir comentarios escritos en español en representaciones numéricas simples para observar vocabulario, bolsa de palabras, TF, TF-IDF y similitud entre documentos.
