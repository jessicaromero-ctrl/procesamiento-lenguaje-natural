"""
UPMH · Procesamiento de Lenguaje Natural · Clase 4
Autor: M.C. Pablo Ricardo Sánchez Gómez

Práctica: clasificación de texto con dataset ampliado y datasets externos tipo Kaggle.

Objetivo:
- Leer un CSV con texto y etiqueta.
- Convertir texto en vectores TF-IDF.
- Comparar modelos clásicos de clasificación de texto.
- Exportar métricas, matriz de confusión, predicciones y errores.

Uso local:
    python clasificacion_texto_kaggle_clase4.py --csv datos/comentarios_ampliados_clase4.csv --text-col texto --label-col categoria

Uso con Kaggle:
    python clasificacion_texto_kaggle_clase4.py --csv datos/archivo_kaggle.csv --text-col NOMBRE_COLUMNA_TEXTO --label-col NOMBRE_COLUMNA_ETIQUETA
"""

from __future__ import annotations

import argparse
import re
import unicodedata
from pathlib import Path
from typing import Dict, List, Tuple

import pandas as pd
import matplotlib.pyplot as plt

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    classification_report,
    confusion_matrix,
)
from sklearn.naive_bayes import MultinomialNB, ComplementNB
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC


def quitar_acentos(texto: str) -> str:
    """Elimina marcas de acento para normalizar palabras en español."""
    normalizado = unicodedata.normalize("NFD", texto)
    return "".join(caracter for caracter in normalizado if unicodedata.category(caracter) != "Mn")


def limpiar_texto(texto: str) -> str:
    """Normaliza texto: minúsculas, sin acentos, sin signos extraños y con espacios uniformes."""
    texto = str(texto).lower()
    texto = quitar_acentos(texto)
    texto = re.sub(r"http\S+|www\S+", " ", texto)
    texto = re.sub(r"[^a-zñ0-9\s]", " ", texto)
    texto = re.sub(r"\s+", " ", texto).strip()
    return texto


def cargar_dataset(ruta_csv: Path, text_col: str, label_col: str, max_rows: int | None = None) -> pd.DataFrame:
    """Carga un CSV y valida que existan las columnas de texto y etiqueta."""
    if not ruta_csv.exists():
        raise FileNotFoundError(f"No existe el archivo CSV: {ruta_csv}")

    df = pd.read_csv(ruta_csv, encoding="utf-8-sig")

    if text_col not in df.columns:
        raise ValueError(f"No existe la columna de texto '{text_col}'. Columnas disponibles: {list(df.columns)}")
    if label_col not in df.columns:
        raise ValueError(f"No existe la columna de etiqueta '{label_col}'. Columnas disponibles: {list(df.columns)}")

    df = df[[text_col, label_col]].dropna()
    df = df.rename(columns={text_col: "texto", label_col: "etiqueta"})
    df["texto"] = df["texto"].astype(str)
    df["etiqueta"] = df["etiqueta"].astype(str)

    if max_rows is not None and max_rows > 0:
        df = df.sample(n=min(max_rows, len(df)), random_state=42)

    df["texto_limpio"] = df["texto"].apply(limpiar_texto)
    df = df[df["texto_limpio"].str.len() > 0].reset_index(drop=True)
    return df


def construir_modelos() -> Dict[str, Pipeline]:
    """Crea pipelines comparables: TF-IDF + modelo de clasificación."""
    vectorizador = TfidfVectorizer(
        lowercase=False,
        ngram_range=(1, 2),
        min_df=2,
        max_df=0.90,
        sublinear_tf=True,
        max_features=5000,
    )

    return {
        "naive_bayes_multinomial": Pipeline([
            ("tfidf", vectorizador),
            ("modelo", MultinomialNB(alpha=1.0)),
        ]),
        "naive_bayes_complement": Pipeline([
            ("tfidf", vectorizador),
            ("modelo", ComplementNB(alpha=1.0)),
        ]),
        "regresion_logistica": Pipeline([
            ("tfidf", vectorizador),
            ("modelo", LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42)),
        ]),
        "svm_lineal": Pipeline([
            ("tfidf", vectorizador),
            ("modelo", LinearSVC(class_weight="balanced", random_state=42)),
        ]),
    }


def evaluar_modelo(nombre: str, modelo: Pipeline, x_train, x_test, y_train, y_test) -> Tuple[dict, pd.DataFrame, pd.DataFrame]:
    """Entrena un modelo, predice y genera métricas, reporte y predicciones."""
    modelo.fit(x_train, y_train)
    y_pred = modelo.predict(x_test)

    metricas = {
        "modelo": nombre,
        "accuracy": accuracy_score(y_test, y_pred),
        "precision_macro": precision_score(y_test, y_pred, average="macro", zero_division=0),
        "recall_macro": recall_score(y_test, y_pred, average="macro", zero_division=0),
        "f1_macro": f1_score(y_test, y_pred, average="macro", zero_division=0),
    }

    reporte = classification_report(y_test, y_pred, output_dict=True, zero_division=0)
    df_reporte = pd.DataFrame(reporte).transpose().reset_index().rename(columns={"index": "clase"})

    predicciones = pd.DataFrame({
        "texto_limpio": x_test,
        "etiqueta_real": y_test,
        "etiqueta_predicha": y_pred,
        "correcto": y_test.values == y_pred,
    })
    return metricas, df_reporte, predicciones


def guardar_matriz_confusion(nombre: str, y_test, y_pred, salida_dir: Path) -> None:
    """Guarda la matriz de confusión en CSV y PNG."""
    etiquetas = sorted(list(set(y_test) | set(y_pred)))
    matriz = confusion_matrix(y_test, y_pred, labels=etiquetas)

    df_matriz = pd.DataFrame(matriz, index=etiquetas, columns=etiquetas)
    df_matriz.to_csv(salida_dir / f"matriz_confusion_{nombre}.csv", encoding="utf-8-sig")

    plt.figure(figsize=(8, 6))
    plt.imshow(matriz)
    plt.title(f"Matriz de confusión - {nombre}")
    plt.xticks(range(len(etiquetas)), etiquetas, rotation=45, ha="right")
    plt.yticks(range(len(etiquetas)), etiquetas)
    plt.xlabel("Predicción")
    plt.ylabel("Real")

    for i in range(len(etiquetas)):
        for j in range(len(etiquetas)):
            plt.text(j, i, matriz[i, j], ha="center", va="center")

    plt.tight_layout()
    plt.savefig(salida_dir / f"matriz_confusion_{nombre}.png", dpi=160)
    plt.close()


def exportar_top_terminos(modelo: Pipeline, nombre: str, salida_dir: Path, top_n: int = 20) -> None:
    """Exporta términos con mayor peso cuando el modelo permite coeficientes interpretables."""
    vectorizador = modelo.named_steps["tfidf"]
    clasificador = modelo.named_steps["modelo"]
    terminos = vectorizador.get_feature_names_out()

    if not hasattr(clasificador, "coef_"):
        return

    clases = clasificador.classes_
    filas = []
    for idx, clase in enumerate(clases):
        coeficientes = clasificador.coef_[idx]
        indices = coeficientes.argsort()[-top_n:][::-1]
        for posicion in indices:
            filas.append({"modelo": nombre, "clase": clase, "termino": terminos[posicion], "peso": coeficientes[posicion]})

    pd.DataFrame(filas).to_csv(salida_dir / f"top_terminos_{nombre}.csv", index=False, encoding="utf-8-sig")


def ejecutar(args) -> None:
    salida_dir = Path(args.output_dir)
    salida_dir.mkdir(parents=True, exist_ok=True)

    df = cargar_dataset(Path(args.csv), args.text_col, args.label_col, args.max_rows)
    df.to_csv(salida_dir / "01_dataset_limpio.csv", index=False, encoding="utf-8-sig")

    conteo_clases = df["etiqueta"].value_counts().rename_axis("clase").reset_index(name="registros")
    conteo_clases.to_csv(salida_dir / "02_distribucion_clases.csv", index=False, encoding="utf-8-sig")

    x_train, x_test, y_train, y_test = train_test_split(
        df["texto_limpio"],
        df["etiqueta"],
        test_size=args.test_size,
        random_state=42,
        stratify=df["etiqueta"],
    )

    modelos = construir_modelos()
    resumen_metricas: List[dict] = []
    todos_errores = []

    for nombre, modelo in modelos.items():
        metricas, reporte, predicciones = evaluar_modelo(nombre, modelo, x_train, x_test, y_train, y_test)
        resumen_metricas.append(metricas)

        predicciones.to_csv(salida_dir / f"predicciones_{nombre}.csv", index=False, encoding="utf-8-sig")
        reporte.to_csv(salida_dir / f"reporte_clasificacion_{nombre}.csv", index=False, encoding="utf-8-sig")
        guardar_matriz_confusion(nombre, y_test, predicciones["etiqueta_predicha"], salida_dir)
        exportar_top_terminos(modelo, nombre, salida_dir)

        errores = predicciones[predicciones["correcto"] == False].copy()
        errores.insert(0, "modelo", nombre)
        todos_errores.append(errores)

    df_metricas = pd.DataFrame(resumen_metricas).sort_values("f1_macro", ascending=False)
    df_metricas.to_csv(salida_dir / "03_comparativo_modelos.csv", index=False, encoding="utf-8-sig")

    if todos_errores:
        pd.concat(todos_errores, ignore_index=True).to_csv(salida_dir / "04_errores_modelos.csv", index=False, encoding="utf-8-sig")

    print("\nEvaluación finalizada.")
    print(df_metricas.to_string(index=False))
    print(f"\nArchivos generados en: {salida_dir.resolve()}")


def crear_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Clasificación de texto para PLN con CSV local o dataset tipo Kaggle.")
    parser.add_argument("--csv", required=True, help="Ruta del archivo CSV de entrada.")
    parser.add_argument("--text-col", required=True, help="Nombre de la columna que contiene el texto.")
    parser.add_argument("--label-col", required=True, help="Nombre de la columna que contiene la etiqueta o categoría.")
    parser.add_argument("--output-dir", default="salidas_clase4", help="Carpeta donde se guardarán resultados.")
    parser.add_argument("--test-size", type=float, default=0.25, help="Proporción del dataset usada como prueba. Valor sugerido: 0.25.")
    parser.add_argument("--max-rows", type=int, default=None, help="Número máximo de filas a usar. Útil para datasets Kaggle muy grandes.")
    return parser


if __name__ == "__main__":
    parser = crear_parser()
    argumentos = parser.parse_args()
    ejecutar(argumentos)
